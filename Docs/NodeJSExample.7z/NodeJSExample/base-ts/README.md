# base
TS NG Webpack

# Start with Docker
docker-compose up --build
Go to: http://localhost:48421/


# Start from scratch and run 
npm run complete
Go to: http://localhost:8421/

---------------------------------------

# Init
npm install

# Start locally
npm start
Go to: http://localhost:8421/

# Start dev
npm run dev
Frontend: http://localhost:4200
backend: http://localhost:8421

# Run tests
npm run test

# Start with Docker
docker-compose up --build

-----------------------------------------------

# Ports on Docker:
Postgres database:
