import { cleanEnv, port, str, email } from 'envalid';

function validateEnv() {
  cleanEnv(process.env, {
    APP_TITLE: str(),
    APP_HOST: str(),
    APP_PORT: port(),
    APP_CONTENT_PATH: str(),
    
    JWT_SECRET: str(),

    POSTGRES_HOST: str(),
    POSTGRES_PORT: port(),
    POSTGRES_USER: str(),
    POSTGRES_PASSWORD: str(),
    POSTGRES_DB: str(),

    HTTPS_KEY: str(),
    HTTPS_CERT: str(),

    AMQP_HOST: str(),
    AMQP_PORT: port(),
    AMQP_USER: str(),
    AMPQ_PASSWORD: str(),
 });
}

export default validateEnv;
