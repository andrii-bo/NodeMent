import NodeFragment from './nodeFragment.interface';

interface NodeData {
    id: number|string|any;
    type: string;
    update: Date;
    sync: {
        [key: string]: string;
    };
    data: {
        [key: string]: NodeFragment;
    };
    _children?: any;
}

export default NodeData;
