import * as WebSocket from 'ws';

interface ExtendedWebSocket extends WebSocket {
  id: string;
}

export default ExtendedWebSocket;
