interface NodeFragment {
    parent: string,
    title: string,
    icon: string,
    position: number,
    reviewGroup: string,
    protected: boolean,
    meta?: {
      [key: string]: object;
    }
    values?: {
      [key: string]: object;
    }
}

export default NodeFragment;
