// Component in hierarchy

interface Component {
  id: number;
  name: string;
  attributes: {
    [key: string]: {
      name: string;
      value: {
        [key: string]: string;
      },
      unit: string;
    };
  };
}

export default Component;
