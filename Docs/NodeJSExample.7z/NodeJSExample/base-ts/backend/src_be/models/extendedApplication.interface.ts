import { Application } from 'express';
import { Connection } from 'amqplib/callback_api';
import * as WebSocket from 'ws';

interface ExtendedApplication extends Application {
  wss: WebSocket;
  amqp: Connection;
}

export default ExtendedApplication;
