interface EventQueue {
    "source":string,
    "timestamp": Date,
    "event": any,
    "data":any
}

export default EventQueue