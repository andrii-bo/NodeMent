//import { Node } from '../entity/Node';
import * as express from 'express';
import ExtendedApplication from 'models/extendedApplication.interface';
//import NodeNotFoundException from '../exceptions/NodeNotFoundException';

export class EventService {
  private app:ExtendedApplication;

  constructor(app:ExtendedApplication) {
    this.app = app;

    this.app.on("event", (...args: any[]) => {
      console.log("-------------------- Event in ... -------------------------");
      console.log(args);
    });
  
  }

  

}

