import * as express from "express";
import * as WebSocket from "ws";
import * as uuid from "uuid";
import * as amqplib from "amqplib";
import ExtendedApplication from 'models/extendedApplication.interface';
import ExtendedWebSocket from 'models/extendedWebSocket.interface';

export class WSSService {
  public server: any;
  public app: ExtendedApplication;
  public wss: any;

  constructor(server: any, app: any) {
    this.server = server;
    this.app = app;
    this.initWSS();
  }

  private initWSS() {
    this.wss = new WebSocket.Server({ server: this.server });
    this.wss.on("connection", (ws: ExtendedWebSocket) => {
      ws.id = uuid.v4().toString();
      ws.on("message", (message: string) => {
        try {
          message = JSON.parse(message);
        } catch(e) {
          console.error(e);
        }
        this.app.emit("event", message);
      });
      ws.on('close', () => {
        console.log('disconnected');
        ws.terminate();
      });
      this.app.wss = this.wss;
    });
  }
}
