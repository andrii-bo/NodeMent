import * as express from "express";
import * as bodyParser from "body-parser";
import * as path from "path";
import * as fs from "fs";
import * as http from "http";
import * as https from "https";
import * as helmet from "helmet";
import * as cors from "cors";
// import * as session from 'express-session';
import * as passport from "passport";
import * as WebSocket from "ws";
import * as uuid from "uuid";
import * as fileUpload from 'express-fileupload';

import { AMQPService } from './amqpService';
import { WSSService } from './wssService';
import { EventService } from './eventService';

import Controller from "models/controller.interface";
import ExtendedWebSocket from "../models/extendedWebSocket.interface";

import authMiddleware from "../middleware/auth.middleware";
import loggerMiddleware from "../middleware/logger.middleware";
import errorMiddleware from "../middleware/error.middleware";
import dynamicMiddleware from "../middleware/dynamic.middleware";

export default class WebServer {
  public app: any; // Application;
  private contentPath: string;
  private host: string;
  private port: number | string;
  public server: any;
  private controllers: Controller[];
  public clientId: string = "";
  public clients: ExtendedWebSocket[] = [];

  private secret: string;

  constructor(controllers: Controller[]) {
    this.contentPath =
      process.env.APP_CONTENT_PATH || path.resolve(__dirname, "./public");
    this.host = process.env.APP_HOST || "0.0.0.0";
    this.port = process.env.APP_PORT || 8080;
    this.secret = process.env.JWT_SECRET || "388E4DA86D895E9FCA06F3162A2537E8";
    this.controllers = controllers;
    this.initServer();
  }

  initServer() {
    this.app = express();
    this.server = http.createServer(this.app);


    this.initializeMiddlewares();

    new EventService(this.app);
    new WSSService(this.server, this.app);
    new AMQPService(this.app);  
 
    this.initializeControllers(this.controllers);
    this.finalizeMiddlewares();

    this.server.listen(this.port, () => {
      console.log(`Server listening on the port ${this.port}`);
    });
  }

  private initializeMiddlewares() {
    this.app.set("trust proxy", 1);
    this.app.use(helmet({ xssFilter: true }));
    // this.app.use(
    //   cors({
    //     origin: "*",
    //     methods: "GET,HEAD,PUT,PATCH,POST,DELETE",
    //     preflightContinue: true,
    //     optionsSuccessStatus: 204
    //   })
    // );
    this.app.use(bodyParser.json());
    this.app.use(bodyParser.urlencoded({ extended: false }));
    this.app.use(fileUpload());
  }

  private initializeControllers(controllers: Controller[]) {
    controllers.forEach(controller => {
      this.app.use("/", controller.router);
    });
  }

  private finalizeMiddlewares() {
    this.app.use(express.static(path.resolve(this.contentPath)));
    this.app.use(express.static(path.resolve(__dirname, "./public")));
    this.app.use(loggerMiddleware);
    this.app.use(errorMiddleware);
    console.log(this.app.eventNames());
  }
}
