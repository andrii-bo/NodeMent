export default class FileService {
    constructor() {
        console.log("FileService initialized");
    }
}