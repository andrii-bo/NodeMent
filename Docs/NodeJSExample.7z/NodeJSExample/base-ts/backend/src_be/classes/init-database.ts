// import { Node } from '../entity/Node';

// class InitDB {
//   private connection = null;
//   private sql: string = `
//   -- Table: public.node
//   -- DROP TABLE public.node;
//   CREATE TABLE public.node (
//     id uuid NOT NULL DEFAULT uuid_generate_v4(),
//     type character varying COLLATE pg_catalog."default" NOT NULL,
//     update timestamp without time zone NOT NULL DEFAULT now(),
//     sync jsonb,
//     data jsonb,
//     CONSTRAINT "PK_8c8caf5f29d25264abe9eaf94dd" PRIMARY KEY (id)
//   )
//   WITH ( OIDS = FALSE ) TABLESPACE pg_default;

//   ALTER TABLE public.node OWNER to admin;
//   `;
//   constructor(conn:) {
//     this.connection = conn;
//     this.init();
//   }

//   private async init() {
//     // console.log('Check DB');

//     // Init database If empty
//     const nodes = await this.connection.manager.find(Node);
//     if (nodes.length === 0) {
//       const node = new Node();
//       node.id = '00000000-0000-4000-8000-000000000000';
//       node.type = 'ROOT';
//       node.update = new Date();
//       node.sync = JSON.parse('{}');
//       node.data = JSON.parse(
//         '{"0":{"icon":"root","meta":{},"title":"Root","parent":"0","values":{"en":{}},"position":10,"protected":true,"reviewGroup":"0"}}'
//       );
//       await this.connection.manager.save(node);
//     }
//   }
// }

// export default InitDB;
/*
https://so.com/questions/38747875/how-to-share-connection-pool-between-modules-in-node-js

var pg = require('pg');
var pool;
var config = {
  user: 'foo',
  database: 'my_db',
  password: 'secret',
  port: 5432, 
  max: 10,
  idleTimeoutMillis: 30000,
};

module.exports = {
    getPool: function () {
      if (pool) return pool; // if it is already there, grab it here
      pool = new pg.Pool(config);
      return pool;
};
*/