import ExtendedApplication from "../models/extendedApplication.interface";
import { Connection } from "amqplib";
import * as amqp from "amqplib/callback_api";
import EventQueue from "models/eventQueue.interface";

export class AMQPService {
  private amqpHost: string | undefined;
  private amqpPort: string | undefined;
  private amqpUser: string | undefined;
  private amqpPwd: string | undefined;
  private app: ExtendedApplication;
  private channel:any;

  constructor(app: ExtendedApplication) {
    this.amqpHost = process.env.AMQP_HOST;
    this.amqpPort = process.env.AMQP_PORT;
    this.amqpUser = process.env.AMQP_USER;
    this.amqpPwd = process.env.AMPQ_PASSWORD;
    this.app = app;
    this.startAMQP();

    this.app.on("AMQP", (...args: any[]) => {
      console.log("-------------------- AMQP send -------------------------");
      console.log(args);
      this.publish("detect_object_req", JSON.stringify(args[0]));
    });
  }

  public startAMQP() {
    const urn = `amqp://${this.amqpUser}:${this.amqpPwd}@${this.amqpHost}:${this.amqpPort}`;
    amqp.connect(urn, (err, conn) => {
      if (err) {
        console.error("[AMQP]", err.message);
        return setTimeout(() => this.startAMQP, 1000);
      }
      conn.on("error", err => {
        if (err.message !== "Connection closing") {
          console.error("[AMQP] conn error", err.message);
        }
      });
      conn.on("close", () => {
        console.error("[AMQP] reconnecting");
        return setTimeout(() => this.startAMQP, 1000);
      });
      this.app.amqp = conn;
      this.initChannels();
      console.log("[AMQP] connected");
    });
    
  }

  public initChannels() {
    this.app.amqp.createChannel((err: any, channel: any) => {
      if (err) {
        throw err;
      }
      this.channel = channel;
      this.channel.assertQueue("detect_object_req", {
        durable: true
      });
      this.channel.assertQueue("detect_object_res", {
        durable: true
      });
      this.channel.consume(
        "detect_object_res",
        (msg: any) => {
          console.log(" [AMQP] Received %s", msg.content.toString());
          const event: EventQueue = {
            source: "AMQP",
            timestamp: new Date(),
            event: msg,
            data: msg.content.toString()
          };
          this.app.emit("event", event);
        },
        {
          noAck: true
        }
      );
      //this.publish("detect_object_req",`{"Hallo":"Welt"}`);
    });
  }
  
  public publish(queueName: string, data: any) {
    if (this.channel != undefined) {
      this.channel.sendToQueue(queueName, new Buffer(data));
    }
  };
}
