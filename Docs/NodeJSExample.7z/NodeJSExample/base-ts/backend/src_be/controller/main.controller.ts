import * as express from 'express';
import Controller from '../models/controller.interface';

class MainController implements Controller {
  public path = '/';
  public router = express.Router();

  constructor() {
    this.intializeRoutes();
  }

  private intializeRoutes() {
    this.router.get(this.path, this.info);
    this.router.get(this.path + 'json', this.actionSender);
  }

  private info = (
    req: express.Request,
    res: express.Response,
    next: express.NextFunction
  ) => {
    //response.render('index', { title: 'Express' });
    next();
  };

  private actionSender = (
    req: express.Request,
    res: express.Response,
    next: express.NextFunction
  ) => {
    console.log(req.headers);
    let data = [];
    data.push({
      type: 'SET_MODEL_BY_PATH',
      payload: {
        date: new Date(),
        event: 'Christmas'
      },
      method: req.method
    });

    data.push({
      type: 'SET_MODEL_BY_PATH',
      payload: { intro: 'ghost' },
      method: req.method
    });

    
    res.json(data);
  };
}
export default MainController;
