import * as express from 'express';
import Controller from '../models/controller.interface';
import * as pg from 'pg';

export default class AuthController implements Controller {
  public path = '/auth';
  public router = express.Router();
  private pool: pg.Pool;

  constructor() {
    this.pool = new pg.Pool({
      user: process.env.POSTGRES_USER,
      host: process.env.POSTGRES_HOST,
      database: process.env.POSTGRES_DB,
      password: process.env.POSTGRES_PASSWORD,
      port: 5432
    });
    this.intializeRoutes();
  }

  private intializeRoutes() {
    this.router.get(`${this.path}/signUp`, this.signUp);
  }

  private signUp() {
      console.log('SignUp');
  }
}