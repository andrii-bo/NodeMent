import * as express from 'express';
import Controller from '../models/controller.interface';
import * as fs from 'fs';
import * as path from 'path';
import HttpException from '../exceptions/HttpException';
// import {publishToQueue} from '../classes/amqp';

import * as amqp from 'amqplib/callback_api';

class MessageController implements Controller {
  public path = '/api/msg';
  public router = express.Router();
  public amqpConn: any;

  public ch: any;

  constructor() {
    this.intializeRoutes();
  }

  private intializeRoutes() {
    this.router.get(`${this.path}`, this.getContent);
  }
  private getContent = async (
    req: express.Request,
    res: express.Response,
    next: express.NextFunction
  ) => {
    //console.log('BODY:', req.body);
    const queue = 'detect_object_req';
    let msg = {
      header: {
        title: '20191104_Freetext',
        description: 'Sample data for first contact',
        uploader: 'optional.user.name@example.com'
      },
      files: [
        {
          id: 'd8da2cb7d5d34fb356a77a5f76b30a12d2ab8571',
          path:
            'c2fdbf9a-124b-4f12-8b0f-6d05605841a2/20191021/rpi_SCH_4b_4p0_reduced.pdf',
          meta: {
            timestamp: new Date()
          }
        }
      ]
    };
    req.app.emit('AMQP', msg);
    res.statusCode = 200;
    res.send(msg);
  };
}
export default MessageController;
