import * as express from 'express';
import Controller from '../models/controller.interface';
import * as fs from 'fs';
import * as path from 'path';
import HttpException from '../exceptions/HttpException';
import * as Busboy from 'busboy';
import * as util from 'util';
import FileService from '../classes/fileService';
import * as crypto from 'crypto';
import * as klawSync from 'klaw-sync';



interface content {
  [key: string]: string[] | any;
}

class FileManagerController implements Controller {
  public path = '/api/fm';
  public router = express.Router();
  private folderPath = './public/files'; ///c2fdbf9a-124b-4f12-8b0f-6d05605841a2/20191021';


  constructor() {
    this.intializeRoutes();
  }

  private intializeRoutes() {
    this.router.get(`${this.path}/tree`, this.getHierarchy);
    this.router.get(`${this.path}`, this.getContent);
    this.router.post(`${this.path}`, this.uploadContent);
    this.router.get(`${this.path}/download/:id`, this.download);
    this.router.delete(`${this.path}/:id`, this.deleteContent);
  }

  private getContent = (
    req: express.Request,
    res: express.Response,
    next: express.NextFunction
  ) => {
    req.app.emit('event', 'Access to file system ....');
    console.log(this.folderPath);
    let content: content = this.getFolderContent(this.folderPath);
    res.json(content);
  };

  private getHierarchy = (
    req: express.Request,
    res: express.Response,
    next: express.NextFunction
  ) => {
    req.app.emit('event', 'Read hierarchy ...');
    console.log(this.folderPath);
    let content: content = this.getFolderHierarchy(this.folderPath);
    res.json(content);
  };


  private uploadContent = (
    req: express.Request,
    res: express.Response,
    next: express.NextFunction
  ) => {
    const busboy = new Busboy({ headers: req.headers });
   

    busboy.on('file', (fieldname, file, filename, encoding, mimetype) => {
      let saveTo = path.join(this.folderPath, path.basename(filename));
      file.on('data', data => {
        // console.log(
        //   'File Data [' + fieldname + '] got ' + data.length + ' bytes'
        // );
        
        file.pipe(fs.createWriteStream(saveTo));
  
      });
      file.on('end', () => {
        // console.log('File End [' + fieldname + '] Finished');
      });


      const queue = 'detect_object_req';
      let msg = {
        header: {
          title: '20191104_Freetext',
          description: 'Sample data for first contact',
          uploader: 'optional.user.name@example.com'
        },
        files: [
          {
            id: 'd8da2cb7d5d34fb356a77a5f76b30a12d2ab8571',
            path:
              saveTo,
            meta: {
              timestamp: new Date()
            }
          }
        ]
      };
      req.app.emit('AMQP', msg);


    });
    busboy.on(
      'field',
      (
        fieldname,
        val,
        fieldnameTruncated,
        valTruncated,
        encoding,
        mimetype
      ) => {
        console.log(
          fieldname,
          val,
          fieldnameTruncated,
          valTruncated,
          encoding,
          mimetype
        );
      }
    );
    busboy.on('finish', () => {
      // req.app.emit('AMQP', 'Lirum Larum...');




      let content: content = this.getFolderContent(this.folderPath);
      console.log('Done parsing form!');
      res.json(content);
    });
    req.pipe(busboy);
  };

  private download = (
    req: express.Request,
    res: express.Response,
    next: express.NextFunction
  ) => {
    const id = req.params.id;
    const filePath = req.body.path || '';

  
    let content: content = this.getFolderContent(this.folderPath);
    const f:string = path.resolve(content[id].path);
    // const filePath = 
    fs.stat(f, (err, stat) => {
      if (err !== null) {
        next(new HttpException(404, 'File Not Found'));
      }
      res.writeHead(200, {
        'Content-Type': 'application/octet-stream; charset=utf-8',
        'Content-Disposition': `attachment; filename="${path.basename(
          f
        )}"`
      });
      const readStream = fs.createReadStream(f).pipe(res);
    });
  };

  private deleteContent = (
    req: express.Request,
    res: express.Response,
    next: express.NextFunction
  ) => {
    const id = req.params.id;
    console.log(id);

 

    let content: content = this.getFolderContent(this.folderPath);
    console.log(content[id].path);
    const f:string = path.resolve(content[id].path);
    fs.unlink(f, (err) => {
      if (err) {
        // throw err;
        console.log('error deleting file');
      }
      console.log('path/file.txt was deleted');
      content[id] = undefined;
      res.json(content);
    });

  };


  private getFolderHierarchy = (folderName: string) => {
     const content = klawSync(path.resolve(this.folderPath), { filter: (item:any) => {
       item.name = path.relative(this.folderPath,item.path);
       item.id = crypto.createHash('sha256').update(item.path).digest('hex');
       console.log(item);
       return item;
    }});

     return content;
  }


  private getFolderContent = (folderName: string) => {
    let content: content = {
    //   '.': { path: path.resolve(folderName), dir: true },
    //   '..': { path: path.resolve(folderName, '..'), dir: true }
    };
    fs.readdirSync(folderName).forEach(file => {
      const stat = fs.statSync(path.resolve(folderName + '/' + file));
      const fn = crypto.createHash('sha256').update(file).digest('hex');
      content[fn] = stat;
      content[fn]['name'] = file;
      content[fn]['path'] = path
        .resolve(folderName + '/' + file)
        //.replace('file://', '');
      if (stat.isDirectory()) {
        content[fn]['dir'] = true;
      } else {
        content[fn]['dir'] = false;
      }
    });
    return content;
  };
}
export default FileManagerController;
