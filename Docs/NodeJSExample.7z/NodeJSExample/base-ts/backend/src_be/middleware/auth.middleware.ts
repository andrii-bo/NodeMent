import { NextFunction, Request, Response } from 'express';

const authMiddleware = (req: Request, res: Response, next: NextFunction) => {
  const auth = { login: process.env.AUTH_EMAIL, password: process.env.AUTH_PW };

  const b64auth = (req.headers.authorization || '').split(' ')[1] || '';
  const [login, password] = new Buffer(b64auth, 'base64').toString().split(':');

  if (login && password && login === auth.login && password === auth.password) {
    next();
  } else {
    res.statusCode = 401;
    res.setHeader('WWW-Authenticate', 'Basic realm="MyRealmName"');
    res.end('Unauthorized');
  }
};

export default authMiddleware;
