import { NextFunction, Request, Response } from 'express';
import * as fs from 'fs';
import * as path from 'path';
import * as url from 'url';
import * as vm from 'vm';

import HttpException from '../exceptions/HttpException';

const dynamicMiddleware = (
  request: Request,
  response: Response,
  next: NextFunction
) => {
  const extensions: string[] = ['.es6', '.node.js'];
  const parsedUrl = url.parse(request.originalUrl);
  let filepath = path.resolve(`${process.env.APP_CONTENT_PATH}${parsedUrl.pathname}`);
  fs.stat(filepath, (err, stats) => {
    if (extensions.filter(el => filepath.indexOf(el) !== -1).length > 0) {
      fs.readFile(filepath, (err, data) => {
        if (err) {
          next();
        } else {
          try {
            vm.runInNewContext(data.toString(), {
              __path: filepath,
              __dirname,
              __filename,
              console,
              require,
              global,
              process,
              request,
              response,
              next
            });
          } catch (e) {
            next(new HttpException(500, e.toString()));
          }
        }
      });
    } else {
      next();
    }
  });
};

export default dynamicMiddleware;
