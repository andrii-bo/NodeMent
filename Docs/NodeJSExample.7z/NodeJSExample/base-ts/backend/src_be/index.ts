import * as dotenv from 'dotenv';
import validateEnv from './utils/validateEnv';
import WebServer from './classes/server';

//import MainController from './controller/main.controller';
//import HelperController from './controller/helper.controller';
//import DataController from './controller/data.controller';
import FileManagerController from './controller/filemanager.controller';
import AuthController from './controller/auth.controller';
import MessageController from './controller/message.controller';

let envFile = '.env';
switch(process.env.NODE_ENV) {
  case 'development': envFile = '.env'; break;
  default: envFile = '.env.production'; break;
}
dotenv.config({path:`environments/${envFile}`});
validateEnv();

//console.log(process.env);

const server = new WebServer ([
    new AuthController(),
    new MessageController(),
    //new HelperController(),
    //new DataController(),
    new FileManagerController(),
]);
