import {
  CreateDateColumn,
  Column,
  Entity,
  PrimaryGeneratedColumn
} from 'typeorm';

@Entity()
export class Node {
@PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  type: string;

  @CreateDateColumn({ type: 'timestamp' })
  update: Date;

  @Column({ type: 'jsonb', nullable: true })
  sync: JSON;

  @Column({ type: 'jsonb', nullable: true })
  data: JSON;
}
