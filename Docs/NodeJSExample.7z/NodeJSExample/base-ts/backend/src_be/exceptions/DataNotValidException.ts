import HttpException from './HttpException';

class DataNotValidException extends HttpException {
  constructor(id: string) {
    super(404, `Input at id ${id} not valid`);
  }
}

export default DataNotValidException;