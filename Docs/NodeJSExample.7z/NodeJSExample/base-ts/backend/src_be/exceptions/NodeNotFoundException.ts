import HttpException from './HttpException';

class NodeNotFoundException extends HttpException {
  constructor(id: string) {
    super(404, `Node with id ${id} not found`);
  }
}

export default NodeNotFoundException;