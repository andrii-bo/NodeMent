import HttpException from './HttpException';

class ParentNotFoundException extends HttpException {
  constructor(id: string) {
    super(404, `Parent of id ${id} not found`);
  }
}

export default ParentNotFoundException;