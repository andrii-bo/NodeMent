import {
  CreateDateColumn,
  Column,
  Entity,
  PrimaryGeneratedColumn
} from 'typeorm';
import NodeData from '../models/node-data.interface';

@Entity()
export class Node implements NodeData {
@PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  type: string;

  @CreateDateColumn({ type: 'timestamp' })
  update: Date;

  @Column({ type: 'jsonb', nullable: true })
  sync: JSON;

  @Column({ type: 'jsonb', nullable: true })
  data: JSON;
}
