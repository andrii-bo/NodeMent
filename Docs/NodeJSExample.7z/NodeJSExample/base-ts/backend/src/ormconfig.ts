import { ConnectionOptions } from 'typeorm';

const config: ConnectionOptions = {
  type: 'postgres',
  host: process.env.POSTGRES_HOST,
  port: Number(process.env.POSTGRES_PORT),
  username: process.env.POSTGRES_USER,
  password: process.env.POSTGRES_PASSWORD,
  database: process.env.POSTGRES_DB,
  synchronize: true,
  logging: false,
  entities: [
    __dirname + '/entity/*{.ts,.js}'
  ],
  migrations: [
    __dirname + '/migration/*.ts',
  ],
  cli: {
    migrationsDir: __dirname + '/migration',
  },
};

export = config;
 