// import * as express from 'express';
// import { NodeFactory } from '../classes/node-factory';
// import { getRepository } from 'typeorm';
// import NodeNotFoundException from '../exceptions/NodeNotFoundException';
// import ParentNotFoundException from '../exceptions/ParentNotFoundException';
// import DataNotValidException from '../exceptions/DataNotValidException';
// import Controller from '../models/controller.interface';
// //import validationMiddleware from '../middleware/validation.middleware';
// //import CreateNodeDto from '../dto/node.dto';
// import { Node } from '../entity/Node';

// import { getConnection } from 'typeorm';

// class NodeController implements Controller {
//   public path = '/api/nodes';
//   public router = express.Router();
//   private NF: NodeFactory;
//   private nodeRepository = getRepository(Node);

//   constructor() {
//     this.NF = new NodeFactory();
//     this.intializeRoutes();
//   }

//   private intializeRoutes() {
//     this.router.get(`${this.path}`, this.getAllNodeIds);
//     this.router.get(`${this.path}/full`, this.getAllNodes);
//     this.router.get(`${this.path}/:id`, this.getNodeById);
//     this.router.get(`${this.path}/:id/parent`, this.getNodeParent);
//     this.router.get(`${this.path}/:id/children`, this.getNodeChildren);
//     this.router.get(`${this.path}/:id/breadcrumb`, this.getBreadcrumb);
//     this.router.get(`${this.path}/:id/hierarchy`, this.getNodeHierarchyById);
//     this.router.get(`${this.path}/byData/:data`, this.getNodesByData);
//     this.router.post(`${this.path}`, this.createNode); //,validationMiddleware(CreateNodeDto),
//     this.router.put(`${this.path}/:id`, this.modifyNode); //,validationMiddleware(CreateNodeDto),
//     this.router.delete(`${this.path}/:id`, this.deleteNode);
//   }

//   private getAllNodeIds = async (
//     request: express.Request,
//     response: express.Response
//   ) => {
//     const nodes = await this.NF.getAllNodeIds();
//     response.send(nodes);
//   };

//   private getAllNodes = async (
//     request: express.Request,
//     response: express.Response
//   ) => {
//     const nodes = await this.NF.getAllNodes();
//     response.send(nodes);
//   };

//   private createNode = async (
//     request: express.Request,
//     response: express.Response,
//     next: express.NextFunction
//   ) => {
//     const nodeData = new Node();
//     nodeData.type = request.body.type;
//     nodeData.update = new Date();
//     nodeData.sync = request.body.sync;
//     nodeData.data = request.body.data;
//     const newNode = this.nodeRepository.create(nodeData);
//     await this.nodeRepository.save(newNode);
//     response.send(newNode);
//   };

//   private getNodeById = async (
//     request: express.Request,
//     response: express.Response,
//     next: express.NextFunction
//   ) => {
//     const id = request.params.id;
//     const node = await this.NF.getNodeById(id);
//     if (node) {
//       response.send(node);
//     } else {
//       next(new NodeNotFoundException(id));
//     }
//   };

//   private modifyNode = async (
//     request: express.Request,
//     response: express.Response,
//     next: express.NextFunction
//   ) => {
//     const id = request.params.id;
//     if (id != '' && request.body.id !='') {
//       const nodeData = {
//         id: request.body.id,
//         type: request.body.type,
//         update: new Date(),
//         sync: request.body.sync,
//         data: request.body.data
//       };
//       await getConnection()
//         .createQueryBuilder()
//         .update(Node)
//         .set(nodeData)
//         .where('id = :id', { id: id })
//         .execute();
//     } else {
//       next(new DataNotValidException(id));
//     }
//     const updatedNode = await this.nodeRepository.findOne(request.body.id);
//     if (updatedNode) {
//       response.send(updatedNode);
//     } else {
//       next(new NodeNotFoundException(id));
//     }
//   };

//   private deleteNode = async (
//     request: express.Request,
//     response: express.Response,
//     next: express.NextFunction
//   ) => {
//     const id = request.params.id;
//     const deleteResponse = await this.nodeRepository.delete(id);
//     if (deleteResponse.affected > 0) {
//       response.sendStatus(200);
//     } else {
//       next(new NodeNotFoundException(id));
//     }
//   };

//   private getNodeParent = async (
//     request: express.Request,
//     response: express.Response,
//     next: express.NextFunction
//   ) => {
//     const id = request.params.id;
//     const node = await this.nodeRepository.findOne(id);
//     if (node && node.data) {
//       try {
//         const data = JSON.parse(JSON.stringify(node.data));
//         const pid = data['0'].parent;
//         console.log('PID...', pid);
//         if (pid != 0) {
//           const parent = await this.nodeRepository.findOne(pid);
//           if (parent) {
//             response.send(parent);
//           } else {
//             next(new ParentNotFoundException(pid));
//           }
//         } else {
//           next(new ParentNotFoundException(pid));
//         }
//       } catch (e) {
//         next(new ParentNotFoundException(id));
//       }
//     } else {
//       next(new NodeNotFoundException(id));
//     }
//   };

//   private getNodeChildren = async (
//     request: express.Request,
//     response: express.Response
//   ) => {
//     const id = request.params.id;
//     //const nodes = await this.NF.getChildren(id);
//     const query = `SELECT * FROM node WHERE data @> '{"0":{"parent":"${id}"}}'`;
//     const nodes = await this.nodeRepository.query(query);
//     response.send(nodes);
//   };

//   private getBreadcrumb = async (
//     request: express.Request,
//     response: express.Response,
//     next: express.NextFunction
//   ) => {
//     const id = request.params.id;
//     let pid = id;
//     let loop = 10;
//     let nodes = [];
//     while (pid != 0 && loop--) {
//       const node = await this.nodeRepository.findOne(pid);
//       if (node && node.data) {
//         const data = JSON.parse(JSON.stringify(node.data));
//         pid = data['0'].parent;
//         nodes.push(node);
//       } else {
//         next(new NodeNotFoundException(id));
//       }
//     }
//     response.send(nodes); //.map(x => x.id));
//   };

//   //TODO: DEV only
//   private getNodesByData = async (
//     request: express.Request,
//     response: express.Response,
//     next: express.NextFunction
//   ) => {
//     const data = request.params.data;
//     const query = `SELECT * FROM node WHERE data @> '${data}'`;
//     const nodes = await this.nodeRepository.query(query);
//     response.send(nodes);
//   };
  
//   //TODO: RECURSIVEDEV only
//   private getNodeHierarchyById = async (
//     request: express.Request,
//     response: express.Response,
//     next: express.NextFunction
//   ) => {
//     const id = request.params.id;
//     const node = await this.NF.getNodeById(id);
//     if (node) {
//       response.send(node);
//     } else {
//       next(new NodeNotFoundException(id));
//     }
//   };

// }

// export default NodeController;
