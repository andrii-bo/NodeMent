export enum AccessLevels {
  User = 'drivetrainmonitoring.user',
  Engineer = 'drivetrainmonitoring.engineer',
  Admin = 'drivetrainmonitoring.admin'
}
