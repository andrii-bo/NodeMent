export const assets = [
  {
    "id": "8566b852-228b-4258-ac5a-79fb19f771ee",
    "type": "ASSET",
    "update": "2019-08-26T20:22:12.223Z",
    "sync": {},
    "data": {
      "0": {
        "icon": "node",
        "meta": {},
        "title": "Inverter 1",
        "parent": "5a9809bf-4077-4485-b25b-becde00b005c",
        "values": {
          "en": {
            "type": "INVERTER",
            "label": "Inverter_0815",
            "source": "https://mindsphere.io/api/SIDRIVE_IQ/",
            "aspects": [
              {
                "unit": "kV",
                "label": "Motor Voltage",
                "value": "1-10"
              },
              {
                "unit": "A",
                "label": "Motor Current",
                "value": "10-20"
              },
              {
                "unit": "V",
                "label": "DC Link Voltage",
                "value": "10-20"
              },
              {
                "unit": "Hz",
                "label": "Pulse Frequency out",
                "value": "60-2000"
              },
              {
                "unit": "%",
                "label": "Efficiency / Usage",
                "value": "90-98"
              },
              {
                "unit": "kNm",
                "label": "Torque",
                "value": "2-5",
                "status": "WARNING"
              },
              {
                "unit": "°C",
                "label": "Temperature",
                "value": "10-60"
              },
              {
                "unit": "U/min",
                "label": "Rot. Speed act",
                "value": "200-400"
              },
              {
                "unit": "U/min",
                "label": "Rot. Speed rev",
                "value": "200-400"
              },
              {
                "unit": "m/s",
                "label": "Velocity actual",
                "value": "10-20"
              },
              {
                "unit": "",
                "label": "Messages",
                "value": "Normal"
              },
              {
                "unit": "",
                "label": "BO Message",
                "value": "Hello"
              }
            ],
            "manufacturer": "Siemens AG"
          }
        },
        "position": 10,
        "protected": false,
        "reviewGroup": "0"
      }
    }
  },
  {
    "id": "29a710c6-3199-4b80-85df-a27033391223",
    "type": "ASSET",
    "update": "2019-08-26T20:25:51.179Z",
    "sync": {},
    "data": {
      "0": {
        "icon": "node",
        "meta": {},
        "title": "Motor 1",
        "parent": "5a9809bf-4077-4485-b25b-becde00b005c",
        "values": {
          "en": {
            "type": "MOTOR",
            "label": "E-Motor_4711",
            "source": "https://mindsphere.io/api/SIDRIVE_IQ/",
            "aspects": [
              {
                "unit": "U/min",
                "label": "Rot. Speed",
                "value": "200-400"
              },
              {
                "unit": "°C",
                "label": "Winding Temperature",
                "value": "50-150"
              },
              {
                "unit": "mm/s²",
                "label": "Acceleration Sum",
                "value": "1-5"
              },
              {
                "unit": "°C",
                "label": "Surface Temp",
                "value": "50-150"
              },
              {
                "unit": "µT",
                "label": "Magnetic Flux",
                "value": "0,1-2"
              }
            ],
            "manufacturer": "Siemens AG"
          }
        },
        "position": 10,
        "protected": false,
        "reviewGroup": "0"
      }
    }
  },
  {
    "id": "9f4bfac0-edca-4081-9e50-54c07c3978fc",
    "type": "ASSET",
    "update": "2019-08-26T21:12:48.951Z",
    "sync": {},
    "data": {
      "0": {
        "icon": "node",
        "meta": {},
        "title": "Gearbox",
        "parent": "5a9809bf-4077-4485-b25b-becde00b005c",
        "values": {
          "en": {
            "type": "GEARBOX",
            "label": "Gearbox_8080",
            "source": "https://mindsphere.io/api/SIDRIVE_IQ/",
            "aspects": [
              {
                "unit": "mm/s²",
                "label": "Acc Sum Bearing 1",
                "value": "1-5"
              },
              {
                "unit": "mm/s²",
                "label": "Acc Sum Bearing 2",
                "value": "1-5"
              },
              {
                "unit": "°C",
                "label": "Temp Bearing 1",
                "value": "50-150"
              },
              {
                "unit": "°C",
                "label": "Temp Bearing 2",
                "value": "50-150"
              },
              {
                "unit": "",
                "label": "Crest Factor Bear.1",
                "value": "0,1-2"
              },
              {
                "unit": "",
                "label": "Crest Factor Bear.2",
                "value": "0,1-3"
              },
              {
                "unit": "",
                "label": "Gear Factor",
                "value": "7,8"
              },
              {
                "unit": "mm/s²",
                "label": "Gear Mesh Freq. Sum",
                "value": "1-5"
              },
              {
                "unit": "mm/s²",
                "label": "Other Freq. Bands",
                "value": "1-5"
              },
              {
                "unit": "Hz",
                "label": "Inner Ring Freq.",
                "value": "2-50"
              },
              {
                "unit": "Hz",
                "label": "Outer Ring Freq.",
                "value": "2-50"
              },
              {
                "unit": "Hz",
                "label": "Ball Frequency",
                "value": "5-100"
              },
              {
                "unit": "°C",
                "label": "Oil Temp",
                "value": "50-150"
              },
              {
                "unit": "°C",
                "label": "Oil Flow",
                "value": "50-150"
              }
            ],
            "manufacturer": "MTU"
          }
        },
        "position": 10,
        "protected": false,
        "reviewGroup": "0"
      }
    }
  },
  {
    "id": "8900f7cb-2e8a-40c4-9c08-4685d5e3a2a2",
    "type": "ASSET",
    "update": "2019-08-26T21:13:44.063Z",
    "sync": {},
    "data": {
      "0": {
        "icon": "node",
        "meta": {},
        "title": "Cylinder 1",
        "parent": "5a9809bf-4077-4485-b25b-becde00b005c",
        "values": {
          "en": {
            "type": "CYLINDER",
            "label": "Cylinder_666",
            "source": "https://mindsphere.io/api/SIDRIVE_IQ/",
            "aspects": [
              {
                "unit": "mm/s²",
                "label": "Acc Sum Bearing 1",
                "value": "1-5"
              },
              {
                "unit": "mm/s²",
                "label": "Acc Sum Bearing 2",
                "value": "1-5"
              },
              {
                "unit": "°C",
                "label": "Temp Bearing 1",
                "value": "50-150"
              },
              {
                "unit": "°C",
                "label": "Temp Bearing 2",
                "value": "50-150"
              },
              {
                "unit": "",
                "label": "Crest Factor Bear. 1",
                "value": "0,1-2"
              },
              {
                "unit": "",
                "label": "Crest Factor Bear. 2",
                "value": "0,1-3"
              },
              {
                "unit": "mm",
                "label": "Cylinder Radius",
                "value": "150"
              },
              {
                "unit": "mm/s²",
                "label": "Other Freq. Bands",
                "value": "1-5"
              },
              {
                "unit": "Hz",
                "label": "Inner Ring Freq.",
                "value": "2-50"
              },
              {
                "unit": "Hz",
                "label": "Outer Ring Freq.",
                "value": "2-50"
              },
              {
                "unit": "Hz",
                "label": "Ball Frequency",
                "value": "5-100"
              },
              {
                "unit": "°C",
                "label": "Oil Temp",
                "value": "50-150"
              },
              {
                "unit": "°C",
                "label": "Oil Flow",
                "value": "50-150"
              }
            ],
            "manufacturer": "KRUPP"
          }
        },
        "position": 10,
        "protected": false,
        "reviewGroup": "0"
      }
    }
  }
  ];
