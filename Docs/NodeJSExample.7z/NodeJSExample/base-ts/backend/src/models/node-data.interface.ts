import NodeFragment from './node-fragment.interface';

interface NodeData {
  id: number | string | any;
  type: string;
  update: Date;
  sync:
    | JSON
    | {
        [key: string]: string;
      };
  data:
    | JSON
    | {
        [key: string]: NodeFragment;
      };
  _children?: NodeData[];
}

export default NodeData;
