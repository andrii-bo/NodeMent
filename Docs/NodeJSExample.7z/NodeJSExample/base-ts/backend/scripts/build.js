const path = require('path');
const childProcess = require("child_process");
const fs = require('fs-extra');

const src = path.resolve('../backend');
const dest = path.resolve('../dist');

console.log(process.argv);

try {
    //fs.removeSync(path.resolve(`${dest}/`));
    fs.copySync(path.resolve(`${src}/package.json`), path.resolve(`${dest}/package.json`));
    fs.copySync(path.resolve(`${src}/environments/`), path.resolve(`${dest}/`));
    fs.copySync(path.resolve(`${src}/public/`), path.resolve(`${dest}/public/`));
    childProcess.exec(`cd ${dest} && npm install --production`);
} catch (err) {
    console.log(err);
}
