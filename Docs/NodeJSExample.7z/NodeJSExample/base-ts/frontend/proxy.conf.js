const PROXY_CONFIG = {
  '/api': {
    target: 'http://localhost:48421',
    secure: false,
    logLevel: 'debug',
    changeOrigin: true,
    pathRewrite: {
      '^/api': '/api'
    }
  },
    '/ws': {
    target: 'http://localhost:8421',
    secure: false,
    ws: true,
    logLevel: 'debug',
    pathRewrite: {
      '^/ws': '/ws'
    }
  }
};

module.exports = PROXY_CONFIG;
