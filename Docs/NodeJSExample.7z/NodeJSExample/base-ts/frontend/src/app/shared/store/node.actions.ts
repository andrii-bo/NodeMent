import { createAction } from '@ngrx/store';

export const getAllNodeIds = createAction('[Node] Get All Node Ids');
export const getNodeById = createAction('[Node] Get Node By Id');
export const getNodeParent = createAction('[Node] Get Node Parent');
export const getNodeChildren = createAction('[Node] Get Node Children');
export const getNodeBreadcrumb = createAction('[Node] Get Node Breadcrumb');

