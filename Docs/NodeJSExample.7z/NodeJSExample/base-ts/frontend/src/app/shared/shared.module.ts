import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SharedRoutingModule } from './shared-routing.module';

import { HomePageComponent } from './containers/home-page/home-page.component';
import { LoginPageComponent } from './containers/login-page/login-page.component';
import { NotFoundPageComponent } from './containers/not-found-page/not-found-page.component';
import { AppComponent } from './containers/app/app.component';

@NgModule({
  declarations: [
    AppComponent,
    HomePageComponent,
    LoginPageComponent,
    NotFoundPageComponent
  ],
  imports: [CommonModule, SharedRoutingModule]
})
export class SharedModule {}
