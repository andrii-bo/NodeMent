import { createAction, props } from '@ngrx/store';

export const openSidenav = createAction('[App] Open Sidenav');
export const closeSidenav = createAction('[App] Close Sidenav');

export const loginUser = createAction('[App] Login',props<{ username: string; password: string }>());
export const setUser = createAction('[App] Set User', props<{ username: string }>());
export const unsetUser = createAction('[App] Unset User');
