import { createReducer, on } from '@ngrx/store';

import * as  AppActions from './app.actions';

export const appFeatureKey = 'app';

export interface State {
  showSidenav: boolean;
  user: string;
}

const initialState: State = {
  showSidenav: true,
  user: undefined
};

export const reducer = createReducer(
  initialState,
  on(AppActions.closeSidenav, state => ({ ...state, showSidenav: false })),
  on(AppActions.openSidenav, state => ({ ...state, showSidenav: true })),
  on(AppActions.setUser, state => ({ ...state, user: 'payload from e.g Effect' })),
  on(AppActions.unsetUser, state => ({ ...state, user: undefined }))
);

export const getShowSidenav = (state: State) => state.showSidenav;
