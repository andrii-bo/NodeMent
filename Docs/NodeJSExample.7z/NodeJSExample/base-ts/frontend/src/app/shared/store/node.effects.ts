import { Injectable } from '@angular/core';

import { Actions, createEffect, ofType } from '@ngrx/effects';
import { asyncScheduler, EMPTY as empty, Observable } from 'rxjs';
import { catchError, map, mergeMap } from 'rxjs/operators';

import { Node } from '../models/';
import * as NodeActions from './node.actions';
import { BackendService } from '../services/backend.service';
import { of } from 'rxjs';

@Injectable()
export class NodeEffects {
  constructor(
    private actions$: Actions,
    private backendSerivce: BackendService
  ) {}
  getAllNodeIds$ = createEffect(() =>
    this.actions$.pipe(
      ofType(NodeActions.getAllNodeIds),
      mergeMap(() =>
        this.backendSerivce.getData('api/nodes/').pipe(
          map(nodes => ({
            type: '[Node] Nodes Load Success',
            payload: nodes
          })),
          catchError(() => of({ type: '[Node] Nodes Loaded Error' }))
        )
      )
    )
  );
}
