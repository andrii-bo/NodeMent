import {
  createSelector,
  createFeatureSelector,
  ActionReducer,
  MetaReducer,
  Action,
  combineReducers,
  ActionReducerMap
} from '@ngrx/store';
import { environment } from '../../environments/environment';
import * as fromRouter from '@ngrx/router-store';
import * as fromApp from '../shared/store/app.reducer';
import { InjectionToken } from '@angular/core';

export interface State {
  [fromApp.appFeatureKey]: fromApp.State;
  router: fromRouter.RouterReducerState<any>;
}

export const ROOT_REDUCERS = new InjectionToken<
  ActionReducerMap<State, Action>
>('Root reducers token', {
  factory: () => ({
    [fromApp.appFeatureKey]: fromApp.reducer,
    router: fromRouter.routerReducer
  })
});

export function logger(reducer: ActionReducer<State>): ActionReducer<State> {
  return (state, action) => {
    const result = reducer(state, action);
    console.groupCollapsed(action.type);
    console.log('prev state', state);
    console.log('action', action);
    console.log('next state', result);
    console.groupEnd();
    return result;
  };
}

export const metaReducers: MetaReducer<State>[] = !environment.production
  ? [logger]
  : [];

export const getAppState = createFeatureSelector<State, fromApp.State>('app');

export const getShowSidenav = createSelector(
  getAppState,
  fromApp.getShowSidenav
);
