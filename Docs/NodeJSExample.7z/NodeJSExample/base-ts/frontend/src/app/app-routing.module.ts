import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { NotFoundPageComponent } from './shared/containers/not-found-page/not-found-page.component';
import { HomePageComponent } from './shared/containers/home-page/home-page.component';
import { LoginPageComponent } from './shared/containers/login-page/login-page.component';

const routes: Routes = [
  {
    path: '',
    redirectTo: '/paste',
    pathMatch: 'full'
  },
  {
    path: 'paste',
    loadChildren: () => import('./paste/paste.module').then(m => m.PasteModule)
  },
  {
    path: 'hp',
    component: HomePageComponent
  },
  {
    path: 'login',
    component: LoginPageComponent
  },
  { path: '**', component: NotFoundPageComponent }
];
@NgModule({
  imports: [RouterModule.forRoot(routes, { onSameUrlNavigation: 'reload' })],
  exports: [RouterModule]
})
export class AppRoutingModule {}
