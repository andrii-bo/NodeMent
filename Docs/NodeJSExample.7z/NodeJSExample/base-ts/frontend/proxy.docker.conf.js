const PROXY_CONFIG = {
  '/api': {
    target: 'http://backend:48421',
    secure: false,
    logLevel: 'debug',
    changeOrigin: true,
    pathRewrite: {
      '^/api': '/api'
    }
  },
  '/ws': {
    target: 'http://backend:48421',
    secure: false,
    ws: true,
    logLevel: 'debug'
  }
};

module.exports = PROXY_CONFIG;
