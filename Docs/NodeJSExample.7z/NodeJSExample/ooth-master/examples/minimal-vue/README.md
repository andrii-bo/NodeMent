# Minimal Vue.js ooth example

This is a minimal ooth example intended for learning that uses Vue.js (https://vuejs.org/) instead of vanilla javascript. Note that on the client side one would rater use the `ooth-client` library instead of performing requests by hand (see other examples for that).

```
yarn
yarn start
```