# Minimal ooth example

This is a minimal vanilla javascript ooth example intended for learning. Note that on the client side one would rater use the `ooth-client` library instead of performing requests by hand (see other examples for that).

```
yarn
yarn start
```