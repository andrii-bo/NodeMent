describe('ooth-user', () => {
  test('no test for you my friend', () => {
    expect(false).toBe(!true);
  });
});
