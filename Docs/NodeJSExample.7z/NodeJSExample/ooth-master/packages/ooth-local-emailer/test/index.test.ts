// Find all related tests in ooth-local
describe('ooth-local-emailer', () => {
  it('does nothing', () => {
    expect(true).toBe(true);
  });
});
